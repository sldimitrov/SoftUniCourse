from pokemon_py import Pokemon


class Trainer:
    def __init__(self, name: str):
        self.name = name
        self.pokemons = []

    def add_pokemon(self, pokemon: str):
        if pokemon not in self.pokemons:
            self.pokemons.append(pokemon)
            return f"Caught {pokemon.name} with health {pokemon.health}"
        else:
            return f"This pokemon is already caught"

    def release_pokemon(self, pokemon_name: str):
        trained_pokemons = trainer.pokemons
        for curr_pokemon in trained_pokemons:
            if pokemon_name == curr_pokemon.name:
                trainer.pokemons.remove(curr_pokemon)
                return f"You have released {curr_pokemon.name}"
            else:
                return f"Pokemon is not caught"

    def trainer_data(self):
        result = []

        result.append(f"Pokemon Trainer {self.name}")
        result.append(f"Pokemon count {len(self.pokemons)}")
        for pokemon in self.pokemons:
            result.append(f"- {Pokemon.pokemon_details(pokemon)}")

        return '\n'.join(result)


pokemon = Pokemon("Pikachu", 90)
print(pokemon.pokemon_details())
trainer = Trainer("Ash")
print(trainer.add_pokemon(pokemon))
second_pokemon = Pokemon("Charizard", 110)
print(trainer.add_pokemon(second_pokemon))
print(trainer.add_pokemon(second_pokemon))
print(trainer.release_pokemon("Pikachu"))
print(trainer.release_pokemon("Pikachu"))
print(trainer.trainer_data())
